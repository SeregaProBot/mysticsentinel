# Деплой на Render (https://render.com)

1. Зарегистрируйтесь на Render.
2. Создайте новый Web Service.
3. Свяжите Render с GitHub и выберите репозиторий с этим кодом.
4. Render автоматически применит:
   - requirements.txt
   - render.yaml
5. Установите переменные окружения:
   - API_TOKEN = <ваш_токен_бота>
   - LOG_CHANNEL_ID = <id_канала_куда_будут_нарушения>
6. Нажмите Deploy.
